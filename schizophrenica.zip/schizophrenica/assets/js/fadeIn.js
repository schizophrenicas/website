window.onload = function() {
    document.body.classList.add('loaded');
};